<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class MySite extends BaseConfig
{
    public $siteName = "Syifa Salsabil Web";
    public $siteEmail = "syifasalsabil@gmail.com";
}
