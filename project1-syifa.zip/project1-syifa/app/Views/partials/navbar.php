<ul style="list-style-type: none;">
    <li style="display: inline;padding: 5px;color:blue;">Home</li>
    <li style="display: inline;padding: 5px;color:blue;">About</li>
    <li style="display: inline;padding: 5px;color:blue;">Contact Us</li>
</ul>